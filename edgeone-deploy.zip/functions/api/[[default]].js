/* ============================================================
   存钱计划 · 云同步后端（EdgeOne Pages Functions + KV）
   与页面 /api/state、/api/snapshots 接口语义一致：
   · GET  /api/state?sc=KEY            → { data: 最新数据或 null }
   · POST /api/state?sc=KEY            → 保存数据（覆盖前自动留档）
   · GET  /api/snapshots?sc=KEY        → { list: [{name}] } 存档列表
   · GET  /api/snapshots/{name}?sc=KEY → { data: 该时点数据 }
   部署时需在控制台把 KV 命名空间绑定到本项目，变量名必须是 KV。
   ============================================================ */

const SHARE_KEY = 'K7M2PQ4XZR8A';   /* 必须与链接里的 sharecode 一致 */
const MAX_SNAPS = 120;              /* 最多保留多少份自动留档 */
const SNAP_GAP = 120000;            /* 两次自动留档的最小间隔（毫秒），控制 KV 写入量 */

const json = (o, st = 200) => new Response(JSON.stringify(o), {
  status: st,
  headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' },
});

function tsName(d = new Date()) {
  const p = n => String(n).padStart(2, '0');
  return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate())
    + '-' + p(d.getHours()) + p(d.getMinutes()) + '-' + p(d.getSeconds());
}

/* KV 绑定变量在运行时以全局或 env 属性两种方式之一暴露，这里做兼容 */
function getKV(env) {
  try { if (typeof KV !== 'undefined' && KV && typeof KV.get === 'function') return KV; } catch (e) {}
  if (env && env.KV && typeof env.KV.get === 'function') return env.KV;
  return null;
}

export async function onRequest({ request, env }) {
  const url = new URL(request.url);
  const p = url.pathname.replace(/\/+$/, '') || '/';

  /* 凭据校验：sharecode / sc 必须与 SHARE_KEY 一致，否则一律 404 */
  const key = url.searchParams.get('sharecode') || url.searchParams.get('sc') || '';
  if (!key || key !== SHARE_KEY) return json({ error: '链接不完整或凭据无效' }, 404);

  const kv = getKV(env);
  if (!kv) return json({ error: 'KV 未绑定：请在控制台为项目绑定 KV 命名空间，变量名 KV' }, 500);

  try {
    /* ---- 最新数据 ---- */
    if (p === '/api/state') {
      if (request.method === 'GET') {
        const raw = await kv.get('state');
        return json({ data: raw ? JSON.parse(raw) : null });
      }
      if (request.method === 'POST') {
        const body = await request.json().catch(() => null);
        const data = body && body.data;
        if (!data || typeof data !== 'object') return json({ error: '数据格式不正确' }, 400);

        const prev = await kv.get('state');
        const metaRaw = await kv.get('meta:lastSnap');
        const lastSnapAt = +metaRaw || 0;
        const now = Date.now();

        /* 覆盖前自动留档（限流：间隔不足则跳过，控制 KV 写入量） */
        if (prev && now - lastSnapAt > SNAP_GAP) {
          const name = tsName();
          const idxRaw = await kv.get('snapindex');
          const idx = idxRaw ? JSON.parse(idxRaw) : [];
          idx.push(name);
          while (idx.length > MAX_SNAPS) {
            const old = idx.shift();
            await kv.delete('snap:' + old);
          }
          await kv.put('snap:' + name, prev);
          await kv.put('snapindex', JSON.stringify(idx));
          await kv.put('meta:lastSnap', String(now));
        }

        await kv.put('state', JSON.stringify(data));
        return json({ ok: true });
      }
      return json({ error: 'method not allowed' }, 405);
    }

    /* ---- 存档列表 ---- */
    if (p === '/api/snapshots') {
      if (request.method !== 'GET') return json({ error: 'method not allowed' }, 405);
      const idxRaw = await kv.get('snapindex');
      const idx = idxRaw ? JSON.parse(idxRaw) : [];
      return json({ list: idx.map(name => ({ name })) });
    }

    /* ---- 读取某份存档 ---- */
    const m = p.match(/^\/api\/snapshots\/([^/]+)$/);
    if (m) {
      if (request.method !== 'GET') return json({ error: 'method not allowed' }, 405);
      const name = decodeURIComponent(m[1]);
      if (!/^\d{8}-\d{4}-\d{2}$/.test(name)) return json({ error: '存档名无效' }, 400);
      const raw = await kv.get('snap:' + name);
      return json({ data: raw ? JSON.parse(raw) : null });
    }

    return json({ error: 'not found' }, 404);
  } catch (e) {
    return json({ error: '服务器内部错误' }, 500);
  }
}
